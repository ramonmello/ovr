<?php

$string['newmodule'] = 'newmodule';

$string['modulename'] = 'newmodule';
$string['modulenameplural'] = 'newmoduleS';

$string['newmodulefieldset'] = 'Custom example fieldset';
$string['newmoduleintro'] = 'newmodule Intro';
$string['newmodulename'] = 'newmodule Name';

?>
